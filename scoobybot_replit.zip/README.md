# ScoobyBot Starter: Weekly Mystery System

A beginner-friendly Discord bot written in Python using `discord.py`.

## What it does

- `/mystery setup` connects the six mystery channels.
- `/mystery start` posts a case to `#weekly-mystery` and the full case to `#case-files`.
- `/mystery clue` releases a clue in `#clue-hunting`.
- `/mystery status` shows the active case and number of clues.
- `/mystery close` closes submissions.
- `/mystery reveal` publishes the culprit and explanation in `#villain-reveals`.

Commands that change a case require the user to have Discord's **Manage Server** permission.

## Step 1: Create the Discord application

1. Open https://discord.com/developers/applications
2. Click **New Application**, name it `ScoobyBot`, and create it.
3. Open the **Bot** section and add/configure the bot user if prompted.
4. Use **Reset Token** or **View Token** to create/copy its token. Keep it secret. Never post it in Discord or commit it to GitHub.
5. In **OAuth2 > URL Generator**, select `bot` and `applications.commands`.
6. Grant only the permissions it needs: View Channels, Send Messages, Embed Links, and Read Message History.
7. Open the generated invite link and add the bot to your server.

## Step 2: Get your server ID

1. In Discord, open **User Settings > Advanced** and enable **Developer Mode**.
2. Right-click or long-press your server icon and choose **Copy Server ID**.
3. Keep the ID private enough not to post it publicly; it is not a password.

## Step 3: Upload the project to GitHub

1. Sign in to https://github.com and create a new **private** repository named `scoobybot`.
2. Upload `main.py` and `requirements.txt` from this folder.
3. Do not upload your bot token or any `.env` file.

## Step 4: Deploy on Render

1. Sign in to https://render.com and connect GitHub.
2. Create a **Background Worker** and select your `scoobybot` repository.
3. Set:
   - Runtime: Python
   - Build command: `pip install -r requirements.txt`
   - Start command: `python main.py`
4. Add environment variables:
   - `DISCORD_TOKEN` = your bot token
   - `GUILD_ID` = your Discord server ID
5. Deploy and inspect the logs. You should see `ScoobyBot is online as ...`.

Check Render's current pricing before choosing a plan. A continuously running worker might require a paid plan.

## Step 5: Connect your channels

In your server, run `/mystery setup` and select each of these channels from Discord's channel picker:

- `#weekly-mystery`
- `#case-files`
- `#clue-hunting`
- `#theory-room`
- `#who-done-it`
- `#villain-reveals`

Then try `/mystery start` with a title and a short story.

## Example commands

- `/mystery start title:The Phantom of Blackwood story:A glowing figure has appeared in the abandoned amusement park. The night guard has vanished. Investigate the clues and question the suspects.`
- `/mystery clue clue:The footprints stop at the funhouse, but the dust inside has been disturbed.`
- `/mystery status`
- `/mystery close`
- `/mystery reveal culprit:Celia Wren explanation:Celia used a hidden projector and backstage passages to stage the haunting.`

## Important first-version limitation

This starter stores case data in `scoobybot_data.json` on the worker's local filesystem. Some hosts, including Render by default, use an ephemeral filesystem, so data can be lost when a service is redeployed or restarted. This starter is for learning and initial testing. Before relying on it for real weekly events, move case storage to a persistent database (such as PostgreSQL) or configure a persistent disk. Do not assume a successful deployment means your case history is safely stored.

## Safety notes

- Never share the bot token. If exposed, reset it in the Discord Developer Portal immediately.
- Only trusted moderators with Manage Server permission should operate case commands.
- Keep the culprit solution in moderator notes until the intended reveal.
- Use a private test server before inviting the bot to a larger community.
